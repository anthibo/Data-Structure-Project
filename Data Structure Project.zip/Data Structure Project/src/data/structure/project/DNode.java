/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data.structure.project;

import java.util.Random;

/**
 *
 * @author Mido Computer
 */
public class DNode {

    DNode Next;
    DNode Pre;
    int Data;
    int priority ;

    public DNode(int Data) {
        this.Data = Data;
        Next = Pre = null ;
        Random random = new Random();
        priority = Math.abs((random.nextInt()%5))+1;
        
    }

}
