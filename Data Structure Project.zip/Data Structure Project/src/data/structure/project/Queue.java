/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data.structure.project;

/**
 *
 * @author Abdulrahman Computer
 */
public class Queue {

    Node head, tail;
    public int size = 0;

    public void enqueue(int data) //add rear 
    {
        Node node = new Node(data);
        if (head == null) {
            head = tail = node;
            head.next = tail;
            tail.next = head;

        } else {
            node.next = head;
            tail.next = node;
            tail = node;

        }
        size++;

    }

    public Node dequeue() {
        Node returnedNode = head;
        if (head == null) {
            returnedNode = null ;
        } 
        else {
            if (head.next == head) {
                head = null;
            } else {
                tail.next = head.next;
                head = head.next;
            }
            size--;
        }

        return returnedNode;
    }
    public boolean isEmpty() {
        return head == null;
    }
    void printQueue() {
        if (head == null) {
            System.out.println("Queue is Empty");
        } else {
            Node temp = head;
            while (temp.next != head) {
                System.out.println(temp.data);
                temp = temp.next;
            }
            System.out.println(temp.data);
        }

    }

}
