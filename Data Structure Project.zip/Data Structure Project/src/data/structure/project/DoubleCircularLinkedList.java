/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data.structure.project;

/**
 *
 * @author Mido Computer
 */
public class DoubleCircularLinkedList {

    DNode head;
    DNode tail;
    int size = 0;

    public DNode removeFront() {

        DNode retNode= head ;
        if (head == null) {
           retNode = null ;
            
        } 
        else {
            if (size == 1) {
                head = tail = null;
            } else {
                head = head.Next;
                head.Pre = tail;
                tail.Next = head;
            }
            size -- ;
        }

        return retNode;

    }

    public void insertSorted(int data) {
        DNode node = new DNode(data);
        if (head == null) // no list created
        {
            head = tail = node;
            head.Next = tail;
            tail.Pre = head;

        } else // add in the last
        {
            if (node.priority < head.priority) {
                node.Next = head;
                head.Pre = node;
                node.Pre = tail;
                head = node;
                tail.Next = head;

            } else {
                if (node.priority >= tail.priority) {
                    tail.Next = node;
                    node.Pre = tail;
                    node.Next = head;
                    tail = node;
                    head.Pre = tail;

                } else // 
                {
                    boolean flag = true;
                    DNode temp = head.Next;
                    while (temp != head && flag) {
                        if (node.priority < temp.priority) {
                            node.Next = temp;
                            node.Pre = temp.Pre;
                            temp.Pre.Next = node;
                            temp.Pre = node;
                            flag = false;

                        } else {
                            temp = temp.Next;
                        }
                    }
                }
            }
        }
        size++;

    }
    public boolean isEmpty() {
        return head == null;
    }

    public void printList() {
        DNode temp = head;
        if (head == null) {
            System.out.println("there's no list ");
        } else {
            while (temp.Next != head) {
                System.out.print(" " + temp.Data + " ->");
                temp = temp.Next;
            }
            System.out.println(temp.Data);
        }
    }

}
