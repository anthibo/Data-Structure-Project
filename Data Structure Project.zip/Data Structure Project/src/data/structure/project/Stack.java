/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data.structure.project;

/**
 *
 * @author Mido Computer
 */
public class Stack {

    private Node top;
    int size = 0;

    public void push(int data) {
        Node node = new Node(data);
        if (top == null) // no stack created 
        {
            top = node;

        } else // there is a stack
        {
            node.next = top;
            top = node;

        }
        size++;
    }

    public Node pop() {
        Node returnedTop = top;
        if (top == null) {
            returnedTop = null;
        } else {
            if (top.next != null) {
                top = returnedTop.next;
            } else if (top.next == null) {
                top = null;
            }

            size--;
        }

        return returnedTop;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return top == null;
    }

    public void showStack() {
        Stack stack = new Stack();
        if (this.top == null) {
            System.out.println("No stack");
        } else {
            while (top != null) {
                stack.push(this.pop().data);
                System.out.println(stack.top.data);
            }
            while (stack.top != null) {
                push(stack.pop().data);
            }

        }

    }

}
